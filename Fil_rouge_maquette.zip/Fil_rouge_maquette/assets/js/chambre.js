const myModal = document.getElementById('myModal')
const btn = document.getElementById('addChambre')
const btnClose = document.getElementById('btn-close')


btn.addEventListener('click', (e) => {
    myModal.style.display="block"
    })
    
    btnClose.addEventListener('click', (e) => {
      myModal.style.display="none"
      })
    