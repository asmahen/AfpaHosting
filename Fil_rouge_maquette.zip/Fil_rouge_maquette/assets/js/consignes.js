let btnModif = document.getElementById('btn__modal__consigne');
let modalConsigne = document.getElementById('consigneModal');
let btnClose = document.getElementById('btn-close');

btnModif.addEventListener('click', (e) =>{
modalConsigne.style.display="block"
})
btnClose.addEventListener('click', (e) =>{
    modalConsigne.style.display = "none"
})