document.addEventListener("DOMContentLoaded", () => {

let semaine = document.getElementById('checkboxSemaine');
let mois = document.getElementById('checkboxMois');
let annee = document.getElementById('checkboxAnnee');
var grapharea = document.getElementById("barChart").getContext("2d");
let graph = document.getElementById('selectGraph');



grapharea = new Chart(document.querySelector('#barChart'), {
    type: 'bar',
    data: {
        // labels: ['Lundi', 'Mardi', 'Mercredi', 'Jeudi', 'Vendredi'],
        datasets: [{
            label: 'Bar Chart',
            // data: [65, 59, 80, 81, 56],
            backgroundColor: [
                'rgba(255, 99, 132, 0.2)',
                'rgba(255, 159, 64, 0.2)',
                'rgba(255, 205, 86, 0.2)',
                'rgba(75, 192, 192, 0.2)',
                'rgba(54, 162, 235, 0.2)',
                'rgba(153, 102, 255, 0.2)',
                'rgba(201, 203, 207, 0.2)'
            ],
            borderColor: [
                'rgb(255, 99, 132)',
                'rgb(255, 159, 64)',
                'rgb(255, 205, 86)',
                'rgb(75, 192, 192)',
                'rgb(54, 162, 235)',
                'rgb(153, 102, 255)',
                'rgb(201, 203, 207)'
            ],
            borderWidth: 1
        }]
    },
    options: {
        scales: {
            y: {
                beginAtZero: true
            }
        }
    }
});





document.querySelector('#selectGraph').addEventListener('change', (e) => {

   
    
    
    if(graph.value == 'semaine'){
        grapharea.destroy()
        grapharea = new Chart(document.querySelector('#barChart'), {
            type: 'bar',
            data: {
                labels: ['Lundi', 'Mardi', 'Mercredi', 'Jeudi', 'Vendredi'],
                datasets: [{
                    label: 'Bar Chart',
                    data: [65, 59, 80, 81, 56],
                    backgroundColor: [
                        'rgba(255, 99, 132, 0.2)',
                        'rgba(255, 159, 64, 0.2)',
                        'rgba(255, 205, 86, 0.2)',
                        'rgba(75, 192, 192, 0.2)',
                        'rgba(54, 162, 235, 0.2)',
                        'rgba(153, 102, 255, 0.2)',
                        'rgba(201, 203, 207, 0.2)'
                    ],
                    borderColor: [
                        'rgb(255, 99, 132)',
                        'rgb(255, 159, 64)',
                        'rgb(255, 205, 86)',
                        'rgb(75, 192, 192)',
                        'rgb(54, 162, 235)',
                        'rgb(153, 102, 255)',
                        'rgb(201, 203, 207)'
                    ],
                    borderWidth: 1
                }]
            },
            options: {
                scales: {
                    y: {
                        beginAtZero: true
                    }
                }
            }
        });
        
        // grapharea.data.labels = ["Lundi", "Mardi", "Mercredi", "Jeudi", "Vendredi"],
        // grapharea.data.datasets[0].data == [65, 59, 80, 81, 56]
        
    }

    if(graph.value == 'mois'){
        // grapharea.data.labels = ['1', '2', '3', '4', '5', '6', '7','8','9', '10', '11', '12','13', '14', '15',
        //         '16', '17', '18', '19','20','21', '22', '23', '24', '25', '26', '27', '28', '29', '30','31'],
        // grapharea.data.datasets[0].data == [65, 59, 80, 81, 56, 55, 40,10,100,50,82,21,65, 59, 80,
        //         81, 56, 55, 40,10,100,50,82,65, 59, 80, 81, 56, 55, 40,10],
        //         console.log(grapharea.id)
        grapharea.destroy()
        grapharea = new Chart(document.querySelector('#barChart'), {
            type: 'bar',
            data: {
                labels: ['1', '2', '3', '4', '5', '6', '7','8','9', '10', '11', '12','13', '14', '15',
                '16', '17', '18', '19','20','21', '22', '23', '24', '25', '26', '27', '28', '29', '30','31'],
                datasets: [{
                    label: 'Bar Chart',
                    data: [65, 59, 80, 81, 56, 55, 40,10,100,50,82,21,65, 59, 80,
                81, 56, 55, 40,10,100,50,82,65, 59, 80, 81, 56, 55, 40,10],
                    backgroundColor: [
                        'rgba(255, 99, 132, 0.2)',
                        'rgba(255, 159, 64, 0.2)',
                        'rgba(255, 205, 86, 0.2)',
                        'rgba(75, 192, 192, 0.2)',
                        'rgba(54, 162, 235, 0.2)',
                        'rgba(153, 102, 255, 0.2)',
                        'rgba(201, 203, 207, 0.2)'
                    ],
                    borderColor: [
                        'rgb(255, 99, 132)',
                        'rgb(255, 159, 64)',
                        'rgb(255, 205, 86)',
                        'rgb(75, 192, 192)',
                        'rgb(54, 162, 235)',
                        'rgb(153, 102, 255)',
                        'rgb(201, 203, 207)'
                    ],
                    borderWidth: 1
                }]
            },
            options: {
                scales: {
                    y: {
                        beginAtZero: true
                    }
                }
            }
        });
    }

    if (graph.value == 'annee'){
        grapharea.destroy()
        grapharea = new Chart(document.querySelector('#barChart'), {
            type: 'bar',
            data: {
                labels: ['Janvier','Fevrier','Mars','Avril','Mai','Juin','Juillet','Septembre','Octobre','Novembre','Decembre'],
                datasets: [{
                    label: 'Bar Chart',
                    data: [65, 59, 80, 81, 56, 55, 40,10,100,50,82,21],
                    backgroundColor: [
                        'rgba(255, 99, 132, 0.2)',
                        'rgba(255, 159, 64, 0.2)',
                        'rgba(255, 205, 86, 0.2)',
                        'rgba(75, 192, 192, 0.2)',
                        'rgba(54, 162, 235, 0.2)',
                        'rgba(153, 102, 255, 0.2)',
                        'rgba(201, 203, 207, 0.2)'
                    ],
                    borderColor: [
                        'rgb(255, 99, 132)',
                        'rgb(255, 159, 64)',
                        'rgb(255, 205, 86)',
                        'rgb(75, 192, 192)',
                        'rgb(54, 162, 235)',
                        'rgb(153, 102, 255)',
                        'rgb(201, 203, 207)'
                    ],
                    borderWidth: 1
                }]
            },
            options: {
                scales: {
                    y: {
                        beginAtZero: true
                    }
                }
            }
        });
    }

});





});