const btnClose = document.getElementById('btn-close')
const btnModalClose = document.getElementById('btn_modal_close')
const btnIncident = document.getElementById('btn-incident')
const modalIncident = document.getElementById('modalIncident')
const addModalIncident = document.getElementById('addModalIncident')
const btnAddIncident= document.getElementById('addIncident')
const toggle = document.getElementById('toggleIncident')


btnIncident.addEventListener('click', (e) => {
    modalIncident.style.display="block"
    })
  btnClose.addEventListener('click', (e) => {
    modalIncident.style.display="none"
  })

  btnAddIncident.addEventListener('click', (e) => {
    addModalIncident.style.display="block"
    })
    
    btnModalClose.addEventListener('click', (e) => {
      addModalIncident.style.display="none"
      })

toggle.addEventListener('click', (e)=>{
  if (toggle.checked){
    document.querySelector('#tableau-avertissements').style.display = "block",
    document.querySelector('#tableau-incidents').style.display = "none"
  }
  else {
    document.querySelector('#tableau-avertissements').style.display = "none",
    document.querySelector('#tableau-incidents').style.display = "block"
  }
})