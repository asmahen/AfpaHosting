var element = document.querySelector('.calendar');
new Calendar(element, {
    language: 'fr'
})

